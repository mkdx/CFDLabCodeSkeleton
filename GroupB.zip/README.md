# CFDLabCodeSkeleton
Code Sceleton for the CFD Lab taught at TUM Informatics

This repository contains

* a makefile
* a parameter file
* the headers
* the files with the respective method stubs
